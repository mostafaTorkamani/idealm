import React from 'react'
import Card from './Card'

export default function HonerElements() {
    return (
        <div>
            <Card/>
        </div>
    )
}

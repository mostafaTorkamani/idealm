import styles from "./loading.module.css";

const BetweenPage = () => {
  return (
    <div className={styles["main"]}>
      <div className={styles["loader"]} />

      <style global jsx>
        {`
         
        `}
      </style>
    </div>
  );
};

export default BetweenPage;

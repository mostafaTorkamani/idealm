import Building from '../../components/buildingPage/Building'

export default function Articles() {
    return (
        <div>
            <Building/>
        </div>
    )
}
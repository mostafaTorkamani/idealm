import Building from '../../components/buildingPage/Building'

export default function News() {
    return (
        <div>
            <Building/>
        </div>
    )
}
import Building from '../../components/buildingPage/Building'

export default function scientificResources() {
    return (
        <div>
            <Building/>
        </div>
    )
}
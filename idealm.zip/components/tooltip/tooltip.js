import React from "react";
import toolStyles from "./tooltip.module.css";
export default function Tooltip() {
  return (
    <div>
     
      
        <div className={toolStyles["hint"]} data-position={4}>
          
            <p>
              The point of using 
            </p>
       
      </div>
    </div>
  );
}

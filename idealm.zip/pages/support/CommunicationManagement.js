import Building from '../../components/buildingPage/Building'

export default function CommunicationManagement() {
    return (
        <div>
            <Building/>
        </div>
    )
}